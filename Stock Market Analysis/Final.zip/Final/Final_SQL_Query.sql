-- create schema named `assignment`--

create schema `assignment`;

-- create bajaj table, we considered Date as primary key as it is unique , taken all column as varchar not to loose no of row --
-- also converted date as date format in next table --
-- imported data using imoport wizard --

CREATE TABLE `Bajaj` (
    `Date` VARCHAR(50) NOT NULL,
    `Open Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `High Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `Low Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `Close Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `WAP` DOUBLE DEFAULT NULL,
    `No.of Shares` INT(11) DEFAULT NULL,
    `No. of Trades` INT(11) DEFAULT NULL,
    `Total Turnover (Rs.)` BIGINT(20) DEFAULT NULL,
    `Deliverable Quantity` VARCHAR(50) DEFAULT NULL,
    `% Deli. Qty to Traded Qty` VARCHAR(50) DEFAULT NULL,
    `Spread High-Low` FLOAT(10 , 2 ) DEFAULT NULL,
    `Spread Close-Open` FLOAT(10 , 2 ) DEFAULT NULL,
    PRIMARY KEY (`Date`)
);

-- verification--
SELECT 
    *
FROM
    `Bajaj`
LIMIT 10;
desc `Bajaj`;-- to verify data type--


CREATE TABLE `Eicher` (
    `Date` VARCHAR(50) NOT NULL,
    `Open Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `High Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `Low Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `Close Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `WAP` DOUBLE DEFAULT NULL,
    `No.of Shares` INT(11) DEFAULT NULL,
    `No. of Trades` INT(11) DEFAULT NULL,
    `Total Turnover (Rs.)` BIGINT(20) DEFAULT NULL,
    `Deliverable Quantity` VARCHAR(50) DEFAULT NULL,
    `% Deli. Qty to Traded Qty` VARCHAR(50) DEFAULT NULL,
    `Spread High-Low` FLOAT(10 , 2 ) DEFAULT NULL,
    `Spread Close-Open` FLOAT(10 , 2 ) DEFAULT NULL,
    PRIMARY KEY (`Date`)
);

-- verification--
SELECT 
    *
FROM
    `Eicher`
LIMIT 10;
desc `Eicher`;-- to verify data type--

CREATE TABLE `Hero` (
    `Date` VARCHAR(50) NOT NULL,
    `Open Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `High Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `Low Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `Close Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `WAP` DOUBLE DEFAULT NULL,
    `No.of Shares` INT(11) DEFAULT NULL,
    `No. of Trades` INT(11) DEFAULT NULL,
    `Total Turnover (Rs.)` BIGINT(20) DEFAULT NULL,
    `Deliverable Quantity` VARCHAR(50) DEFAULT NULL,
    `% Deli. Qty to Traded Qty` VARCHAR(50) DEFAULT NULL,
    `Spread High-Low` FLOAT(10 , 2 ) DEFAULT NULL,
    `Spread Close-Open` FLOAT(10 , 2 ) DEFAULT NULL,
    PRIMARY KEY (`Date`)
);
-- verification--
SELECT 
    *
FROM
    `Eicher`
LIMIT 10;
desc `Eicher`;-- to verify data type --

CREATE TABLE `Infosys-old` (
    `Date` VARCHAR(50) NOT NULL,
    `Open Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `High Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `Low Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `Close Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `WAP` DOUBLE DEFAULT NULL,
    `No.of Shares` INT(11) DEFAULT NULL,
    `No. of Trades` INT(11) DEFAULT NULL,
    `Total Turnover (Rs.)` BIGINT(20) DEFAULT NULL,
    `Deliverable Quantity` VARCHAR(50) DEFAULT NULL,
    `% Deli. Qty to Traded Qty` VARCHAR(50) DEFAULT NULL,
    `Spread High-Low` FLOAT(10 , 2 ) DEFAULT NULL,
    `Spread Close-Open` FLOAT(10 , 2 ) DEFAULT NULL,
    PRIMARY KEY (`Date`)
);
-- verification--
SELECT 
    *
FROM
    `Infosys-old`
LIMIT 10;
desc `Infosys-old`;-- to verify data type--

CREATE TABLE `TCS-old` (
    `Date` VARCHAR(50) NOT NULL,
    `Open Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `High Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `Low Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `Close Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `WAP` DOUBLE DEFAULT NULL,
    `No.of Shares` INT(11) DEFAULT NULL,
    `No. of Trades` INT(11) DEFAULT NULL,
    `Total Turnover (Rs.)` BIGINT(20) DEFAULT NULL,
    `Deliverable Quantity` VARCHAR(50) DEFAULT NULL,
    `% Deli. Qty to Traded Qty` VARCHAR(50) DEFAULT NULL,
    `Spread High-Low` FLOAT(10 , 2 ) DEFAULT NULL,
    `Spread Close-Open` FLOAT(10 , 2 ) DEFAULT NULL,
    PRIMARY KEY (`Date`)
);

-- verification--
SELECT 
    *
FROM
    `TCS-old`
LIMIT 10;
desc `TCS-old`;-- to verify data type--

CREATE TABLE `TVS` (
    `Date` VARCHAR(50) NOT NULL,
    `Open Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `High Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `Low Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `Close Price` FLOAT(10 , 2 ) DEFAULT NULL,
    `WAP` DOUBLE DEFAULT NULL,
    `No.of Shares` INT(11) DEFAULT NULL,
    `No. of Trades` INT(11) DEFAULT NULL,
    `Total Turnover (Rs.)` BIGINT(20) DEFAULT NULL,
    `Deliverable Quantity` VARCHAR(50) DEFAULT NULL,
    `% Deli. Qty to Traded Qty` VARCHAR(50) DEFAULT NULL,
    `Spread High-Low` FLOAT(10 , 2 ) DEFAULT NULL,
    `Spread Close-Open` FLOAT(10 , 2 ) DEFAULT NULL,
    PRIMARY KEY (`Date`)
);
-- verification--
SELECT 
    *
FROM
    `TVS`
LIMIT 10;
desc `TVS`;-- to verify data type--


CREATE TABLE `Bajaj Auto` AS SELECT STR_TO_DATE(Date, '%d-%M-%Y') AS New_date,
    `Open Price`,
    `High Price`,
    `Low Price`,
    `Close Price`,
    `WAP`,
    `No.of Shares`,
    `No. of Trades`,
    `Total Turnover (Rs.)`,
    `Deliverable Quantity`,
    `% Deli. Qty to Traded Qty`,
    `Spread High-Low`,
    `Spread Close-Open` FROM
    `Bajaj`;
 
 
CREATE TABLE `Eicher Motors` AS SELECT STR_TO_DATE(Date, '%d-%M-%Y') AS New_date,
    `Open Price`,
    `High Price`,
    `Low Price`,
    `Close Price`,
    `WAP`,
    `No.of Shares`,
    `No. of Trades`,
    `Total Turnover (Rs.)`,
    `Deliverable Quantity`,
    `% Deli. Qty to Traded Qty`,
    `Spread High-Low`,
    `Spread Close-Open` FROM
    `Eicher`;
 
 
CREATE TABLE `Hero Motocorp` AS SELECT STR_TO_DATE(Date, '%d-%M-%Y') AS New_date,
    `Open Price`,
    `High Price`,
    `Low Price`,
    `Close Price`,
    `WAP`,
    `No.of Shares`,
    `No. of Trades`,
    `Total Turnover (Rs.)`,
    `Deliverable Quantity`,
    `% Deli. Qty to Traded Qty`,
    `Spread High-Low`,
    `Spread Close-Open` FROM
    `Hero`;
 
 
CREATE TABLE `Infosys` AS SELECT STR_TO_DATE(Date, '%d-%M-%Y') AS New_date,
    `Open Price`,
    `High Price`,
    `Low Price`,
    `Close Price`,
    `WAP`,
    `No.of Shares`,
    `No. of Trades`,
    `Total Turnover (Rs.)`,
    `Deliverable Quantity`,
    `% Deli. Qty to Traded Qty`,
    `Spread High-Low`,
    `Spread Close-Open` FROM
    `Infosys-old`;
 
CREATE TABLE `TCS` AS SELECT STR_TO_DATE(Date, '%d-%M-%Y') AS New_date,
    `Open Price`,
    `High Price`,
    `Low Price`,
    `Close Price`,
    `WAP`,
    `No.of Shares`,
    `No. of Trades`,
    `Total Turnover (Rs.)`,
    `Deliverable Quantity`,
    `% Deli. Qty to Traded Qty`,
    `Spread High-Low`,
    `Spread Close-Open` FROM
    `TCS-old`;
 
 
CREATE TABLE `TVS Motors` AS SELECT STR_TO_DATE(Date, '%d-%M-%Y') AS New_date,
    `Open Price`,
    `High Price`,
    `Low Price`,
    `Close Price`,
    `WAP`,
    `No.of Shares`,
    `No. of Trades`,
    `Total Turnover (Rs.)`,
    `Deliverable Quantity`,
    `% Deli. Qty to Traded Qty`,
    `Spread High-Low`,
    `Spread Close-Open` FROM
    `TVS`;


WITH bajaj_new (`New_Date`, `close price`, RowNumber, `20 Day MA`, `50 Day MA`)
AS
(
SELECT `New_Date`,`close price`,
ROW_NUMBER() OVER (ORDER BY `New_Date` ASC) RowNumber,
AVG(`close price`) OVER (ORDER BY `New_Date` ASC ROWS 19 PRECEDING) AS `20 Day MA`,
AVG(`close price`) OVER (ORDER BY `New_Date` ASC ROWS 49 PRECEDING) AS `50 Day MA`
FROM `bajaj auto`
)
SELECT `New_Date`,
RowNumber,
`close price`,
IF(RowNumber > 19, `20 Day MA`, NULL) `20 Day MA`,
IF(RowNumber > 49, `50 Day MA`, NULL) `50 Day MA`,
CASE
WHEN RowNumber <49 THEN "NULL"
WHEN RowNumber > 49 AND `20 Day MA` > `50 Day MA`  AND lag(`20 Day MA`) over (order by `New_Date`) < lag(`50 Day MA`) over (order by `New_Date`)   THEN "BUY"
WHEN RowNumber > 49 AND `20 Day MA` < `50 Day MA`  AND lag(`20 Day MA`) over (order by `New_Date`) > lag(`50 Day MA`) over (order by `New_Date`) THEN "SELL"
ELSE "HOLD"
END as `signal`
FROM bajaj_new;

-- created table. Where I have created 20 days MA and 50 Days MA. --

CREATE TABLE `bajaj1` (
    `Date` DATE,
    `Close Price` DOUBLE,
    `20 Day MA` DOUBLE,
    `50 Day MA` DOUBLE
);



insert into `bajaj1`
(`Date`,`Close Price`,`20 Day MA`,`50 Day MA`)

select  `New_date` ,`Close Price`,
if (ROW_NUMBER() OVER w >19,
avg(`close price`)  over(order by `New_date` asc rows between 19 preceding and current row),NULL) as '20 Day MA' ,
if (ROW_NUMBER() OVER w >49,
avg(`close price`)  over(order by `New_date` asc rows between 49 preceding and current row),NULL) as '50 Day MA' 
from `bajaj auto`
window w as (order by `New_date` asc);

SELECT 
    *
FROM
    `bajaj1`;



CREATE TABLE `Eicher1` (
    `Date` DATE,
    `Close Price` DOUBLE,
    `20 Day MA` DOUBLE,
    `50 Day MA` DOUBLE
);



insert into `Eicher1`
(`Date`,`Close Price`,`20 Day MA`,`50 Day MA`)

select  `New_date` ,`Close Price`,
if (ROW_NUMBER() OVER w >19,
avg(`close price`)  over(order by `New_date` asc rows between 19 preceding and current row),NULL) as '20 Day MA' ,
if (ROW_NUMBER() OVER w >49,
avg(`close price`)  over(order by `New_date` asc rows between 49 preceding and current row),NULL) as '50 Day MA' 
from `Eicher Motors`
window w as (order by `New_date` asc);

SELECT 
    *
FROM
    `Eicher1`;


CREATE TABLE `Hero1` (
    `Date` DATE,
    `Close Price` DOUBLE,
    `20 Day MA` DOUBLE,
    `50 Day MA` DOUBLE
);



insert into `Hero1`
(`Date`,`Close Price`,`20 Day MA`,`50 Day MA`)

select  `New_date` ,`Close Price`,
if (ROW_NUMBER() OVER w >19,
avg(`close price`)  over(order by `New_date` asc rows between 19 preceding and current row),NULL) as '20 Day MA' ,
if (ROW_NUMBER() OVER w >49,
avg(`close price`)  over(order by `New_date` asc rows between 49 preceding and current row),NULL) as '50 Day MA' 
from `Hero Motocorp`
window w as (order by `New_date` asc);

SELECT 
    *
FROM
    `Hero1`;


CREATE TABLE `Infosys1` (
    `Date` DATE,
    `Close Price` DOUBLE,
    `20 Day MA` DOUBLE,
    `50 Day MA` DOUBLE
);



insert into `Infosys1`
(`Date`,`Close Price`,`20 Day MA`,`50 Day MA`)

select  `New_date` ,`Close Price`,
if (ROW_NUMBER() OVER w >19,
avg(`close price`)  over(order by `New_date` asc rows between 19 preceding and current row),NULL) as '20 Day MA' ,
if (ROW_NUMBER() OVER w >49,
avg(`close price`)  over(order by `New_date` asc rows between 49 preceding and current row),NULL) as '50 Day MA' 
from `Infosys`
window w as (order by `New_date` asc);

SELECT 
    *
FROM
    `Infosys1`;


CREATE TABLE `TCS1` (
    `Date` DATE,
    `Close Price` DOUBLE,
    `20 Day MA` DOUBLE,
    `50 Day MA` DOUBLE
);



insert into `TCS1`
(`Date`,`Close Price`,`20 Day MA`,`50 Day MA`)

select  `New_date` ,`Close Price`,
if (ROW_NUMBER() OVER w >19,
avg(`close price`)  over(order by `New_date` asc rows between 19 preceding and current row),NULL) as '20 Day MA' ,
if (ROW_NUMBER() OVER w >49,
avg(`close price`)  over(order by `New_date` asc rows between 49 preceding and current row),NULL) as '50 Day MA' 
from `TCS`
window w as (order by `New_date` asc);

SELECT 
    *
FROM
    `TCS1`;


CREATE TABLE `TVS1` (
    `Date` DATE,
    `Close Price` DOUBLE,
    `20 Day MA` DOUBLE,
    `50 Day MA` DOUBLE
);



insert into `TVS1`
(`Date`,`Close Price`,`20 Day MA`,`50 Day MA`)

select  `New_date` ,`Close Price`,
if (ROW_NUMBER() OVER w >19,
avg(`close price`)  over(order by `New_date` asc rows between 19 preceding and current row),NULL) as '20 Day MA' ,
if (ROW_NUMBER() OVER w >49,
avg(`close price`)  over(order by `New_date` asc rows between 49 preceding and current row),NULL) as '50 Day MA' 
from `TVS Motors`
window w as (order by `New_date` asc);

SELECT 
    *
FROM
    `TVS1`;


-- created master table of all 6 tables . Joined by Date as. Applied inner join--

CREATE TABLE master_table AS SELECT b.`New_Date` AS `Date`,
    b.`Close Price` AS Bajaj,
    tc.`Close Price` AS TCS,
    tv.`Close Price` AS TVS,
    i.`Close Price` AS Infosys,
    e.`Close Price` AS Eicher,
    h.`Close Price` AS Hero FROM
    `bajaj auto` b
        INNER JOIN
    `TCS` tc ON b.`New_Date` = tc.`New_Date`
        INNER JOIN
    `TVS Motors` tv ON b.`New_Date` = tv.`New_Date`
        INNER JOIN
    `Infosys` i ON b.`New_Date` = i.`New_Date`
        INNER JOIN
    `Eicher Motors` e ON b.`New_Date` = e.`New_Date`
        INNER JOIN
    `Hero Motocorp` h ON b.`New_Date` = h.`New_Date`
ORDER BY b.`New_Date`;

SELECT 
    *
FROM
    master_table;



-- created final table having signal of whether to buy or sell or hold a stock -- 

CREATE TABLE `bajaj2` (
    `Date` DATE,
    `Close Price` DOUBLE,
    `signal` VARCHAR(50)
);

SELECT 
    *
FROM
    `bajaj2`;


insert into `bajaj2`
(`Date`,`Close Price`,`signal`)

SELECT `Date`,
`close price`,
CASE

WHEN  ROW_NUMBER() OVER w>49 AND `20 Day MA` > `50 Day MA`  AND lag(`20 Day MA`) over (order by `Date`) < lag(`50 Day MA`) over (order by `Date`)   THEN "BUY"
WHEN  ROW_NUMBER() OVER w>49  AND `20 Day MA` < `50 Day MA`  AND lag(`20 Day MA`) over (order by `Date`) > lag(`50 Day MA`) over (order by `Date`) THEN "SELL"
ELSE "HOLD"
END as `signal`
FROM bajaj1
window w as (order by `Date` asc);

SELECT 
    `Date`, `signal`
FROM
    bajaj2
WHERE
    `signal` != 'HOLD';



CREATE TABLE `Eicher2` (
    `Date` DATE,
    `Close Price` DOUBLE,
    `signal` VARCHAR(50)
);

SELECT 
    *
FROM
    `Eicher2`;


insert into `Eicher2`
(`Date`,`Close Price`,`signal`)

SELECT `Date`,
`close price`,
CASE

WHEN  ROW_NUMBER() OVER w>49 AND `20 Day MA` > `50 Day MA`  AND lag(`20 Day MA`) over (order by `Date`) < lag(`50 Day MA`) over (order by `Date`)   THEN "BUY"
WHEN  ROW_NUMBER() OVER w>49  AND `20 Day MA` < `50 Day MA`  AND lag(`20 Day MA`) over (order by `Date`) > lag(`50 Day MA`) over (order by `Date`) THEN "SELL"
ELSE "HOLD"
END as `signal`
FROM Eicher1
window w as (order by `Date` asc);

SELECT 
    `signal`, COUNT(*)
FROM
    Eicher2
GROUP BY `signal`;




CREATE TABLE `Hero2` (
    `Date` DATE,
    `Close Price` DOUBLE,
    `signal` VARCHAR(50)
);

SELECT 
    *
FROM
    `Hero2`;


insert into `Hero2`
(`Date`,`Close Price`,`signal`)

SELECT `Date`,
`close price`,
CASE

WHEN  ROW_NUMBER() OVER w>49 AND `20 Day MA` > `50 Day MA`  AND lag(`20 Day MA`) over (order by `Date`) < lag(`50 Day MA`) over (order by `Date`)   THEN "BUY"
WHEN  ROW_NUMBER() OVER w>49  AND `20 Day MA` < `50 Day MA`  AND lag(`20 Day MA`) over (order by `Date`) > lag(`50 Day MA`) over (order by `Date`) THEN "SELL"
ELSE "HOLD"
END as `signal`
FROM Hero1
window w as (order by `Date` asc);

SELECT 
    `signal`, COUNT(*)
FROM
    Hero2
GROUP BY `signal`;


CREATE TABLE `Infosys2` (
    `Date` DATE,
    `Close Price` DOUBLE,
    `signal` VARCHAR(50)
);

SELECT 
    *
FROM
    `Infosys2`;


insert into `Infosys2`
(`Date`,`Close Price`,`signal`)

SELECT `Date`,
`close price`,
CASE

WHEN  ROW_NUMBER() OVER w>49 AND `20 Day MA` > `50 Day MA`  AND lag(`20 Day MA`) over (order by `Date`) < lag(`50 Day MA`) over (order by `Date`)   THEN "BUY"
WHEN  ROW_NUMBER() OVER w>49  AND `20 Day MA` < `50 Day MA`  AND lag(`20 Day MA`) over (order by `Date`) > lag(`50 Day MA`) over (order by `Date`) THEN "SELL"
ELSE "HOLD"
END as `signal`
FROM Infosys1
window w as (order by `Date` asc);

SELECT 
    `signal`, COUNT(*)
FROM
    Infosys2
GROUP BY `signal`;


CREATE TABLE `TCS2` (
    `Date` DATE,
    `Close Price` DOUBLE,
    `signal` VARCHAR(50)
);

SELECT 
    *
FROM
    `TCS2`;


insert into `TCS2`
(`Date`,`Close Price`,`signal`)

SELECT `Date`,
`close price`,
CASE

WHEN  ROW_NUMBER() OVER w>49 AND `20 Day MA` > `50 Day MA`  AND lag(`20 Day MA`) over (order by `Date`) < lag(`50 Day MA`) over (order by `Date`)   THEN "BUY"
WHEN  ROW_NUMBER() OVER w>49  AND `20 Day MA` < `50 Day MA`  AND lag(`20 Day MA`) over (order by `Date`) > lag(`50 Day MA`) over (order by `Date`) THEN "SELL"
ELSE "HOLD"
END as `signal`
FROM TCS1
window w as (order by `Date` asc);

SELECT 
    `signal`, COUNT(*)
FROM
    TCS2
GROUP BY `signal`;

CREATE TABLE `TVS2` (
    `Date` DATE,
    `Close Price` DOUBLE,
    `signal` VARCHAR(50)
);

SELECT 
    *
FROM
    `TVS2`;


insert into `TVS2`
(`Date`,`Close Price`,`signal`)

SELECT `Date`,
`close price`,
CASE

WHEN  ROW_NUMBER() OVER w>49 AND `20 Day MA` > `50 Day MA`  AND lag(`20 Day MA`) over (order by `Date`) < lag(`50 Day MA`) over (order by `Date`)   THEN "BUY"
WHEN  ROW_NUMBER() OVER w>49  AND `20 Day MA` < `50 Day MA`  AND lag(`20 Day MA`) over (order by `Date`) > lag(`50 Day MA`) over (order by `Date`) THEN "SELL"
ELSE "HOLD"
END as `signal`
FROM TVS1
window w as (order by `Date` asc);

SELECT 
    `signal`, COUNT(*)
FROM
    TVS2
GROUP BY `signal`;
SELECT 
    *
FROM
    tvs2;



-- Create a User defined function, that takes the date as input and returns the signal for that particular day (Buy/Sell/Hold) for the Bajaj stock -- 

delimiter $$
CREATE FUNCTION output1(`@date1` date)

returns varchar(50) 

deterministic

begin

declare `final_signal` varchar(50);

select `signal` into `final_signal` from  bajaj2 where `Date` = `@date1`;

return `final_signal`;

end;
$$
delimiter ;

-- verification of user defined function --
SELECT OUTPUT1('2018-06-21') AS `signal`;

-- proper final verification whether data showing correctly or not --
SELECT 
    `Date`, `signal`
FROM
    bajaj2
WHERE
    `signal` != 'HOLD';
    
    
    
SELECT 
    `Date`, `signal`
FROM
    eicher2
WHERE
    `signal` != 'HOLD';
    
    
SELECT 
    `Date`, `signal`
FROM
    hero2
WHERE
    `signal` != 'HOLD';
    
    
SELECT 
    `Date`, `signal`
FROM
    infosys2
WHERE
    `signal` != 'HOLD';
    
    
SELECT 
    `Date`, `signal`
FROM
    tcs2
WHERE
    `signal` != 'HOLD';
    
    
SELECT 
    `Date`, `signal`
FROM
    tvs2
WHERE
    `signal` != 'HOLD';
    
    


SELECT 
    `signal`, COUNT(*)
FROM
    bajaj2
GROUP BY `signal`;


SELECT 
    `signal`, COUNT(*)
FROM
    eicher2
GROUP BY `signal`;


SELECT 
    `signal`, COUNT(*)
FROM
    hero2
GROUP BY `signal`;


SELECT 
    `signal`, COUNT(*)
FROM
    infosys2
GROUP BY `signal`;



SELECT 
    `signal`, COUNT(*)
FROM
    tcs2
GROUP BY `signal`;


SELECT 
    `signal`, COUNT(*)
FROM
    tvs2
GROUP BY `signal`;



